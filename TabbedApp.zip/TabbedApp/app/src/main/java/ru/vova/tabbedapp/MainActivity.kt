package ru.vova.tabbedapp

import android.app.TabActivity
import android.content.Intent
import android.os.Bundle
import android.widget.TabHost.TabSpec


class MainActivity : TabActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        // получаем TabHost
        // получаем TabHost
        val tabHost = tabHost

        // инициализация была выполнена в getTabHost
        // метод setup вызывать не нужно


        // инициализация была выполнена в getTabHost
        // метод setup вызывать не нужно
        var tabSpec: TabSpec

        tabSpec = tabHost.newTabSpec("tag1")
        tabSpec.setIndicator("Вкладка 1")
        tabSpec.setContent(Intent(this, OneActivity::class.java))
        tabHost.addTab(tabSpec)

        tabSpec = tabHost.newTabSpec("tag2")
        tabSpec.setIndicator("Вкладка 2")
        tabSpec.setContent(Intent(this, TwoActivity::class.java))
        tabHost.addTab(tabSpec)
    }
}