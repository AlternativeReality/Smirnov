package ru.vova.tabbedapp


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
class TwoActivity : AppCompatActivity()  {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.two)
    }
}